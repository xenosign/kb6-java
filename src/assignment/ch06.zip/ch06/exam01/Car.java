package assignment.ch06.exam01;

public class Car {
    //필드선언
    String model;  // null
    boolean start; // false
    int speed;     // 0
}
