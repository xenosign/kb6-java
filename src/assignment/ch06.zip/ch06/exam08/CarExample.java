package assignment.ch06.exam08;

public class CarExample {
    public static void main(String[] args) {
        Car myCar = new Car();

        myCar.setGas(5);
        myCar.run();
    }
}
