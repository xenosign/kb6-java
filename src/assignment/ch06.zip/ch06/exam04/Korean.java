package assignment.ch06.exam04;

public class Korean {
    //필드선언
    String nation = "대한민국";
    String name;
    String ssn;

    //생성자선언
    public Korean(String name, String ssn) {
        this.name = name;
        this.ssn = ssn;
    }
}
