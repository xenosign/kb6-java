package assignment.ch06.exam10;

public class Calculator {
    int areaRectangle(int width) {
        return width * width;
    }

    int areaRectangle(int width, int height) {
        return width * height;
    }
}
