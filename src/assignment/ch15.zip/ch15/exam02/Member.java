package assignment.ch15.exam02;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Member {
    public String name;
    public int age;
}
