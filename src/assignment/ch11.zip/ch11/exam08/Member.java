package assignment.ch11.exam08;

public record Member(String id, String name, int age) {
}
